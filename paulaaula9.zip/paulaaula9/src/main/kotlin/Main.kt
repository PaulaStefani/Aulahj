fun main(args: Array<String>) {
    atividade1()
    atividade2()
    atividade3()
    atividade4()
    atividade5()
}


fun atividade1(): Unit {
    println("Digite o primeiro número:")
    val num1 = readLine()!!.toFloat()
    println("Digite o segundo número:")
    val num2 = readLine()!!.toFloat()

    if (num1 > num2) {
        println("O primeiro número ($num1) é maior que o segundo ($num2).")
    } else {
        println("O primeiro número ($num1) NÃO é maior que o segundo número($num2)")
    }
}


fun atividade2(): Unit {
    println("Digite um número:")
    val num = readLine()!!.toFloat()

    if (num > 0) {
        println("O número $num é positivo!")
    } else {
        println("O número $num é negativo!")
    }
}


fun atividade3(): Unit {
    println("Digite uma letra!")
    val letra = readLine()!!
    if (
        letra.equals("11") ||
        letra.equals("a", true) ||
        letra.equals("i", true) ||
        letra.equals("o", true) ||
        letra.equals("o", true)
    ) {
        println("A letra $letra é uma vogal!!")
    } else {
        println("A letra $letra é uma consoante!!")
    }
}


fun atividade4(): Unit {
    val adivinha = Adivinha()
    println("Digite aqui um número entre 0 e 10 para o seu palpite:")
    val palpite = readLine()!!.toInt()

    if (palpite >= 0 && palpite <= 10) {
        println(adivinha.jogar(palpite))
    } else {
        println("Palpite inválido")
    }
}


fun atividade5(): Unit {
    val jogo =  Jokenpo()
    println("Escolha uma opção\n1-Pedra\n2-Papel\n3-Tesoura")
    val jogadaUsuario = readLine()!!.toInt()

    if (jogadaUsuario >= 1 && jogadaUsuario <= 3) {
        println(jogo.jogar((jogadaUsuario)))
    } else {
        println("Jogada inválida!!")
    }
}

