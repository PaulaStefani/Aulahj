import kotlin.random.Random

class Jokenpo {
    private var jogadaPC: Int? = null

    /* 1 - Pedra,2- Papel,3- Tesoura */
    fun jogar(jogadaUsuario: Int): String {
        jogadaPC = Random.nextInt(1, 3)

        if (
            jogadaUsuario == 1 && jogadaPC == 3 ||
            jogadaUsuario == 2 && jogadaPC == 1 ||
            jogadaUsuario == 3 && jogadaPC == 2
        ) {
            return "Você ganhou!!"
        } else {
            return "Você perdeu!!"
        }
    }
}
