import kotlin.random.Random

class Adivinha {
    private var numeroSorteado: Int? = null
    private fun sortear() = Random.nextInt(0, 10)
    fun jogar(palpite: Int): String {
        numeroSorteado = sortear()

        if (palpite == numeroSorteado) {
            return "Você acertou o palpite!!!"
        }
        return "Lamento, você errou. O número correto é: $numeroSorteado!!!"
    }
}